//
//  RestaurantDetailTableViewCell.swift
//  text2
//
//  Created by RTC41 on 2017/10/20.
//  Copyright © 2017年 RTC34. All rights reserved.
//

import UIKit

class RestaurantDetailTableViewCell: UITableViewCell {
    @IBOutlet var fieldLabel : UILabel!
    @IBOutlet var valueLabel : UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
